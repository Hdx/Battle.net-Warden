#include "module.h"

typedef uint32_t (__stdcall  *db_callback)      (uint32_t color, uint8_t *message, uint32_t length);
void db_output(uint32_t callback, uint32_t color, uint8_t *string){
  ((db_callback)callback)(color, string, strlen(string));
}

#define module_get_int32(a, b) \
	(*(uint32_t*)(a + (uint32_t)b))

#define module_get_aint32(a, b) \
	(*(uint32_t*)(&a[b]))

#define module_get_int16(a, b) \
	(*(uint16_t*)&a[(uint32_t)b])

#define module_get_int8(a, b) \
    (*(uint8_t*)&a[(uint32_t)b])

#define module_swap_int16(a) \
	(((a & 0xFF00) >> 8) | ((a & 0xFF) << 8))

#define module_set_int32(a, b, c)\
  (*(uint32_t*)(a + b) = c)

uint32_t memalloc(uint32_t size){
	LPVOID x;
	x = VirtualAlloc(NULL, size, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	VirtualLock(x, size);
	return (uint32_t)x;
}

int __stdcall module_prep(uint8_t *source, uint32_t cb){
  uint32_t src_location;
  uint32_t dest_location;
  uint16_t length = 0;
  uint8_t bskip = 0;
  uint16_t *refs;
  uint32_t x = 0;
  uint32_t y = 0;
  library_referance *libs;
  uint8_t *lib;
  HMODULE handle;
  uint32_t function;
  uint32_t func;
  uint8_t *msgbuff;
	uint32_t dest;
	uint32_t max_size;
  module_header *header = (pmodule_header)source;

	max_size = module_get_prep_size(source);
	dest = memalloc(max_size);
	memset((uint8_t*)dest, 0, max_size);

  msgbuff = safe_malloc(500);
  sprintf_s(msgbuff, 500, "Warden Base: 0x%08X", (uint32_t)dest); 
	db_output(cb, 0xffffff, msgbuff);
  
	memcpy((uint8_t*)dest, source, sizeof(module_header));

  src_location = sizeof(module_header) + (header->unknown5 * 12);
  dest_location = module_get_aint32(source, 40);

  db_output(cb, 0x00ff00, "Copying code blocks to module");

  while(dest_location < header->maped_size){
    length = module_get_int16(source, src_location);
    src_location += 2;
    if(!bskip){
      memcpy((uint8_t*)(dest + dest_location), source + src_location, length);
      src_location += length;
    }
    bskip = !bskip;
    dest_location += length;
  } 

  refs = (uint16_t*)(dest + header->ref_table);
  dest_location = 0;

  sprintf_s(msgbuff, 500, "Adjusting %d references to global variables...", (int)header->ref_count);
  db_output(cb, 0x00ff00, msgbuff);

  for(x = 0; x < header->ref_count; x++){
    dest_location += module_swap_int16(refs[x]);
	module_set_int32(dest, dest_location, (module_get_int32(dest, dest_location) % max_size) + dest);
  }

  db_output(cb, 0xff00, "Updating API library referances...");

	libs = (plibrary_referance)(dest + header->lib_table);
  for(x = 0; x < header->lib_count; x++){
		lib = (uint8_t*)(dest + libs[x].name_address);
    handle = LoadLibrary(lib);

    function = libs[x].function_table;
    while(module_get_int32(dest, function) != 0){
			func = module_get_int32(dest, function);
			if((func & 0x7FFFFFFF) > max_size){
				sprintf_s(msgbuff, 500, "Attempted to read API from offset pass end of module: 0x%08X", func);
				db_output(cb, 0x00ff, msgbuff);
				break;
			}
      if(func & 0x80000000){
        y = (uint32_t)GetProcAddress(handle, (LPCSTR)(func & 0x7FFFFFFF));
      }else{
				y = (uint32_t)GetProcAddress(handle, (uint8_t*)(dest + func));
      }
			module_set_int32(dest, function, y);
      function += 4;
    }
  }
	return dest;
}
int __stdcall module_get_init_address(uint32_t module){
	uint32_t x = module_get_int32(module, 0x10);
	return module_get_int32(module, x);
}

int __stdcall module_init(uint32_t address, uint32_t callbacks){
  module_init_t init = (module_init_t)address;
	return init(callbacks);
}

void __stdcall module_init_rc4(uint32_t callback, uint8_t *init_data, uint8_t *data, uint32_t data_length){
  module_init_return* init = (module_init_return*)init_data;
  module_init_ran_data rc4_init = (module_init_ran_data)init->exports->rc4_init;
  uint8_t *bah = safe_malloc(500);

  db_output(callback, 0xffffff, "Init_Data:");
  sprintf_s(bah, 500, "  Exports:         0x%08X", init->exports); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    RC4 Init:      0x%08X", init->exports->rc4_init); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    Handle Packet: 0x%08X", init->exports->handle_packet); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    Unload:        0x%08X", init->exports->unload_module); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "  Unknown1:        0x%08X 0x%08X 0x%08X 0x%08X 0x%08X", init->unknown1[0], init->unknown1[1], init->unknown1[2], init->unknown1[3], init->unknown1[4]); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "  CallBacks:       0x%08X", init->callbacks); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    Send Packet:   0x%08X", init->callbacks->c->send_packet); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    Check Mod:     0x%08X", init->callbacks->c->check_module); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    Mod Load:      0x%08X", init->callbacks->c->module_load); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    MemAlloc:      0x%08X", init->callbacks->c->mem_alloc); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    MemFree:       0x%08X", init->callbacks->c->mem_free); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    Set RC4:       0x%08X", init->callbacks->c->set_rc4); db_output(callback, 0xffffff, bah);
  sprintf_s(bah, 500, "    get RC4:       0x%08X", init->callbacks->c->get_rc4); db_output(callback, 0xffffff, bah);

  sprintf_s(bah, 500, "  Unknown2:        0x%08X", init->unknown2); db_output(callback, 0xffffff, bah);

  sprintf_s(bah, 500, "Init 0x%08x 0x%08x", &init_data, init->callbacks->c->get_rc4); db_output(callback, 0xffffff, bah);
  rc4_init((uint32_t*)init_data, (uint32_t)0, data, data_length);
}


uint32_t __stdcall module_handle_packet(uint8_t *init_data, uint8_t *data, uint32_t length){
  uint32_t handled = -1;
  module_init_return *init = (module_init_return*)init_data;
  module_handle_packet_t handle = (module_handle_packet_t)init->exports->handle_packet;
  handle((uint32_t*)init_data, (uint32_t)0, data, length, &handled);
  return handled;
}